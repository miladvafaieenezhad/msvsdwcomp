# Cell Veneer

Scripting used to generate a wrapping around cells to make a boundary more
suitable for place and route.
